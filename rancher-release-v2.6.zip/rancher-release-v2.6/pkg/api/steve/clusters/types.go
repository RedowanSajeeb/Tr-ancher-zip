package clusters

type GenerateKubeconfigOutput struct {
	Config string `json:"config,omitempty"`
}
