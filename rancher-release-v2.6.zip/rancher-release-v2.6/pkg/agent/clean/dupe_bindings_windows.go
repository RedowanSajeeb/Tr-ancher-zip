package clean

import (
	restclient "k8s.io/client-go/rest"
)

func DuplicateBindings(clientConfig *restclient.Config) error {
	return nil
}
