package clean

import restclient "k8s.io/client-go/rest"

func OrphanBindings(clientConfig *restclient.Config) error {
	return nil
}
