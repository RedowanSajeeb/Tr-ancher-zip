package client

const (
	NamespaceSpecType = "namespaceSpec"
)

type NamespaceSpec struct {
}
