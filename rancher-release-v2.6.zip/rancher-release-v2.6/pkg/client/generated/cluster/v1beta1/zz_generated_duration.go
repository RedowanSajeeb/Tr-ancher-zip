package client

const (
	DurationType = "duration"
)

type Duration struct {
}
