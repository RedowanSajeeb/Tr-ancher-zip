Start-Process -NoNewWindow -Wait -FilePath "c:\etc\rancher\agent.exe" -ArgumentList $args
exit 0
